# 1]  introduce yourself
# 2] Briefly explain your projects
# 3] what is your view on social media? (discussion for 4-5 min)
# 4] situational question like what will you do if your teammate is not working properly?

#  skillup project detials  ==> 
- ADMIN Username ==> umang19000
- ADMIN Password ==> Umang2000*


# 1]  Tell me about yourself?/ Introduce yourself.

My name is Priyanka Phulmante. I’m from Latur, Maharashtra. But currently, I live in Pune.

talking about my education Details  recently, I have completed  full-stack web development course at Masai School, bengalore. I have  completed my graduation Bachelor in computer science from Dayanand Science College, Latur. 

Coming to my technical stack I am good in frontend and backend technology. I worked on frontend technical stack Like  html css javascript react redux and used external css library like chakra-UI , Bootstrap, Material-Ui and I familiar with  backend Technologies like Node.js, Express.js and NoSql mongodb database

Talking about my family 
There are 4 members in my family my father and mother are both teachers. my elder sister is a software engineer at Infosys. In my free time, I listen to music, I feel free and relax. 

# 2] will you learn new languages 
Yes , I am adptive person. I like learning new things and technologies so I am always ready to learn new things interested in this role.

# 2]  Tell me about your work experience?

I don’t have any formal work experience but I got hands-on experience building projects at Masai School.
I worked on exciting projects like the skill up website and the clone of KindMeal.my website. I got to use HTML, CSS, Javascript, bootstrap, react.js, node.js, MongoDB, express.js, and MERN stack during these projects.


# 3]  What would you say are your(professional) strengths?

My greatest strength is that I follow discipline about work deadlines and I am so  dedicated to working that I completed all the assignments or tasks given to me within a deadline. Recently, I worked on a clone of an skill-up project at Masai school. I also submitted it on time.  I am very collaborative. and I've always enjoyed working in teams, which is one of my strongest attributes.


# 4]  What would you say are your(professional) weaknesses?
My weakness is that I am not satisfied until I complete the work assigned to me. My weakness is that I cannot say no to others when they ask for help. 


# 5]  What are your future goals? Where do you see yourself in 5 years?

My short-term goal is to get a job as a software developer and rather work in a   professional environment for the next 2-3 years and gain experience. I want to grow in the IT profession, and become a top expert in frontend and backend technologies within five years.

# 6]  Which project that you did at Masai School did you find the most challenging and why? Tell me about the project which you made.

The project I made in unit 5 was an E-commerce skill-up website. The skill-up project basically sells the courses on demand online teaching like udemy.

Objective⇒ the skill-up mission is to provide flexible, effective skill development education. Providing a skill-up platform with many courses in many fields like Learn programming, marketing, data science, and more.

Skill-up is a unique project because skill-up is not a clone of any website. Rather than just taking a theme of this udemy website. 

This project was a collaborative project. In my project team, there were  4 members. My project was completed within a week with support from my team members. We have completed 90% functionality of the website and due to the time limit we could not do the remaining functionality but in the future, we will do so.


In this project, my task was to create a user signup page, and a user login page with authentication, and helped my one of teammates create add cart functionality. This was my overall contribution to the team project.

When I was working on a project I used functionalities like React.js, Node.js, Express, MongoDB, Redux-Thunk, CRUD operation, Firebase, Render
I used an external CSS library, like a bootstrap, react-component
 
When I was doing the project I learned a lot. I learned how to develop,  write logic and implement coding. I have better in coding after joining Masai Coding School.


In the project work, the most challenging part was user direct login with our google account but with my friends' support, I was able to do it. I watched videos online on youtube and talked with my friends to overcome the challenges.


# 1] about project , full responsive
# 2] objective of projcet 
# 3] collbravtive project , temametes
# 4] area of responsibllity
# 5] teachnical stack , external css library 
# 6] most challengining part authentication using forebase

# admin 



# Explain way⇒
Navbar horizontal, vertical
Homepage, footer
User signup, use login with authentication
Courses Cart page, add to cart functionality
Admin Login 

# functionality⇒
User Login signup with authentication
Add-to-cart functionality
Carousel functionality
Dark and light modes enable the functionality
Dropdown functionality
Admin login with authentication 
Talking about Responsiveness
I will show the Codebase of this website

They Ask about to explain deeply your project (then they ask)

# 1] Skillup Project ⇒ 
Skill-Up is a global destination for teaching and learning online. It is a unique project and we've made some interesting changes where a user and admin can both login into different pages and changes made on an admin's page, can be seen on the user's page.

# 2] kind meal.my website  clone ⇒

It's Malaysia's leading meat-free lifestyle platform, indulging you with delicious discounted vegetarian meals at a cost environment we aim to encourage people in reducing meat consumption saving precious animal lives, health, the environment, and money with testy meals. I used for this project Technical  Stack HTML, CSS, JavaScript, Import-Export, and API.



# 7] Why do you want to work with us? Or Why did you decide to apply to_(company)?
I’m excited by the work you do in the field of software development and I had a dream of working with a successful and reputed organization.  I've gone through your company's profile and where learned that your company encourages freshers' talent and provides a good work culture. I think it is a golden opportunity for me to start my career and enhance my skills. I've known about your company for a long time and really admire it.

# 8]  Why should we hire you?/ Why do you think you are eligible for this job? / How can you contribute? / How will you be an asset to our company?

As per your requirement, I have all the skills that you need for this profile. since I am a Masai school student. I have done more projects during my professional training course and I got good marks on these projects. I have also collaborated with different teams during my projects. So I know very well how to work with a team and teammates. I am sure I will be able to contribute something capable to the growth of the company.

# 9] What is your greatest personal/professional achievement so far?

I have actively participated in and successfully certified the NSS  program. I was a volunteer for 3 days college Nss program. where I have to do various types of tasks like explaining why important tree plantation, and saving water. I have actively participated in a college-level annual function in my 2nd year of college. Our team is the runner-up in the drama competition.

NSS ⇒  Worked in the rural development wing of NSS, Dayanand Science College, visited the slum areas, educated the masses, and comprehended field reports. Also, I actively participated in the Donation drives.

(Then they ask)
Drama name ⇒ women empowerment
Moral ⇒ Awareness of women's empowerment

# 10] What does your perfect day/workday look like? Take me through it.

 I am a person whose habit is waking up early in the morning at least before 6 am every day. So after completing all my work, I have a regular habit of cleaning my laptop and my seating area every day, After that, I am checking my emails, slack and it helps me to prioritize my work for the whole day based on that I am priorities my work and started doing my work as per prioritization. After completing my priority work I have a habit of making notes of that in my diary. This way I am doing my work one by one. I am connected daily with my family on a video call or audio call during my dinner at night. After completing dinner before sleeping I check my social media groups and take updates on social media from the news or connect with my friends.  I slept out before 11.30 every day at night in this way my day is completed every day. But some days something changes due to some genuine issue but still, I am completing my daily work. So my perfect day looks like this.

# 11] What has been your experience at Masai school?

Masai School is one of the revolutionary types of coding schools. In my 20's, after completing my journey from Masai school. I have learned a lot of things.  I have learned the importance of soft skills nowadays,  nothing but power skills in corporate sectors. I have to learn the Importance of knowledge and How knowledge is converted into skills. That is the experience In Masai School.


# 14] Why is there a gap in your employment / Gap years after your education?
 (If applicable)

After completing my graduation I have been preparing for the state services examination for  2 years and my Mpsc pre-examination was cleared. Still, because of the pandemic situation there is a lot of delays in the main examination. So I chose to shift my career into the IT industry. Now I'm fully focused on becoming a full-stack developer and improving my coding skills.

# 15] Can you explain why you changed your career paths? (If applicable)/Why have you changed your Jobs so frequently?

After completing my graduation I have been preparing for the state services examination for 2 years and my Mpsc pre-examination was cleared. Still, because of the pandemic situation there is a lot of delay in the mains examination. So I chose to shift my career to the IT industry. Now I'm fully focused on becoming a full-stack developer and improving my coding skills.

# 16] Why did you join Masai school?/Why are you shifting government exam preparation to IT jobs?/ Why did you leave your previous job? (If applicable)

After completing my graduation I have been preparing for the state services examination for 2 years and my Mpsc pre-examination was cleared. Still, because of the pandemic situation there is a lot of delay in the mains examination. So I chose to shift my career to the IT industry. Masai school is one of the best institutes for full-stack development courses. And  I want to learn new programming languages and gain knowledge and experience from them. Now I'm fully focused on becoming a full-stack developer and improving my coding skills. 


# 12]  What is your salary exception for this job?
Since  I am fresher my first target is to launch my career in the IT field. Here  I want to grow my skills and gain experience. I hope The organization helps me to enhance my skills in the web development field. So taking into consideration all the parameters just I have mentioned My expected CTC is that 6 to 7 LPA. I believe according to your company's rules and regulations.
you will give me a standard package for this job role.

# 13] How did you hear about the position?
 I heard about this position from our placement team.


# 17] Do you have any questions for us?
Yes mam I have one question If I  get selected by your company will I go through the training or I get on the project directly?








