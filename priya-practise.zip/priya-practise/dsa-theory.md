# DSA-INTERVIEW-THEORY-QUESTION

 # what are data structure?
 It is a methods and technique used to maintain a data structure is an organized manner.

 # define data dependancy and relationships.
 it is used to handling and storing a data.

 # what is difference between file structure and data structure
 1] file structure==> 
 -data stores on a disc .
 -standard file storage policies.
 -low compatibility with external apps.

 2] data structure ==>
 -data stored on both ram and disc .
 -custmomized storage policies.
 -high compatibility with external apps.


 # what is a linked list
 -data structure that consist of individual entities is called nodes. 
 -nodes have the compatibility to connect to other nodes and create a chain. 
 -the continue chain structure form to become a linked list.
 -the types of linked list are: single linked list , double linked list and circular linked list.

 # where are data structure premariliary used?
  1] numerical computution.
  2] operating system design.
  3] Artificial Intelligence.
  4] compiler design.
  5] database handling.
  6] graphical processing.
  7] lexical analysis.
  8] statistics.

  # what are the types of searching used in data structures?
  1] Linear search : involves iterating over a data unit in order to perform the required operation.
  2] Binary search : Is more effeicient in a way that it has the abillity to split the data unit into chunks and then perform search.
   
 # how does binary search work?
   -binary search works on ordered data(sorted only).
   -to begin with the middle element of the array is found out and the search from there.
   -the array is serached in two parts based on the search value being higher or lower than middle element.
   -it is key to know the order of the arrangment to help search the value accordingly.

# how are individual elements accessed in array?
   -each of the array in an array is given an index position starting from 0 , n-1, where 'n' is the number  of elements in the array.
   -individuals elements can be accessed by using the index element for opertion.
   -multi-diamensional arrays will have more than one diamension to work with.

# what is queue in data structure ?
 - A queue is a useful data structre in programming.
 - it is simillar to the ticket queue outside a cinema hall. where first person entering the queue is the first person who gets  the  ticket. 
 - queue follows the first in first out (FIFO).

 # what is binary tree?
 -A binary tree as the name suggests, is tree data structure with two nodes. which are the nodes on the left and right side of the root node.
 -In usage, binary trees are considered to be an extended linked list.

 